# Release Notes

## v2.0.0 (2018-07-12)

- Names of several Sens'it APIs have been changed.
- Sigfox APIs headers have been added.
- Sens'it APIs to send Sigfox messages have been removed and these functions are now available as sample codes.
- An API to use the i2c bus and to have a direct access to sensors has been added.
- Sens'it APIs to use sensors have been removed and these functions are now available as sample codes.
- Button and reed switch interrupt are now configurable.
- SDK size optimization. You can gain up to 1kB on your firmware size.

## v1.0.0 (2017-12-04)

- First release
