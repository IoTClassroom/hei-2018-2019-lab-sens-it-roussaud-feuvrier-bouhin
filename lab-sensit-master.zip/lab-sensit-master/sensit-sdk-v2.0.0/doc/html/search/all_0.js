var searchData=
[
  ['bool',['bool',['../sensit__types_8h.html#a97a80ca1602ebf2303258971a2c938e2',1,'sensit_types.h']]]
];
