var searchData=
[
  ['true',['TRUE',['../sensit__types_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'sensit_types.h']]]
];
