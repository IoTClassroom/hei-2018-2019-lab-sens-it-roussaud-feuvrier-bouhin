var searchData=
[
  ['sensit_5fnv_5fmem_5fsize',['SENSIT_NV_MEM_SIZE',['../sensit__api_8h.html#a2bdddfbb23567951088dd92b119d4bac',1,'sensit_api.h']]]
];
