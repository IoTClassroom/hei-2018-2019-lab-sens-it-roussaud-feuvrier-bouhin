var searchData=
[
  ['radio_5fconf_5fe',['radio_conf_e',['../sensit__api_8h.html#adce0751287eca928c9a31483a0c93fd9',1,'sensit_api.h']]],
  ['rc_5forigin_5fe',['rc_origin_e',['../sensit__api_8h.html#a27f9b493a5d583199778c145d0d35471',1,'sensit_api.h']]],
  ['rgb_5fcolor_5fe',['rgb_color_e',['../sensit__api_8h.html#a7205560afbc85d1e838360e5143b510b',1,'sensit_api.h']]]
];
