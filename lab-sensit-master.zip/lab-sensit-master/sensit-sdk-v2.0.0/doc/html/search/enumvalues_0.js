var searchData=
[
  ['fxos8700_5frange_5f2g',['FXOS8700_RANGE_2G',['../fxos8700_8h.html#a01d2b55e1e26e87746705dd682e1f052a52b4f763baff8a40bd9bbf52ea4a7a82',1,'fxos8700.h']]],
  ['fxos8700_5frange_5f4g',['FXOS8700_RANGE_4G',['../fxos8700_8h.html#a01d2b55e1e26e87746705dd682e1f052a8ebbe79f8bc8daf64f1dca766676479b',1,'fxos8700.h']]],
  ['fxos8700_5frange_5f8g',['FXOS8700_RANGE_8G',['../fxos8700_8h.html#a01d2b55e1e26e87746705dd682e1f052ae0aba87e9fb029fa3c7c02cf12af4023',1,'fxos8700.h']]]
];
