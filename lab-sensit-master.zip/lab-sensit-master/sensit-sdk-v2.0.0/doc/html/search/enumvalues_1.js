var searchData=
[
  ['interrupt_5fboth_5fegde',['INTERRUPT_BOTH_EGDE',['../sensit__api_8h.html#a496e538298b0c59fa2c7265e7ed3c039aa01c0a6e570873577e199811abdd8619',1,'sensit_api.h']]],
  ['interrupt_5ffalling_5fegde',['INTERRUPT_FALLING_EGDE',['../sensit__api_8h.html#a496e538298b0c59fa2c7265e7ed3c039a6aa1ee854a3912f627c8fb02d0c6768e',1,'sensit_api.h']]],
  ['interrupt_5fnone',['INTERRUPT_NONE',['../sensit__api_8h.html#a496e538298b0c59fa2c7265e7ed3c039a39847f0f1985dd3d23df71cdc290ceb7',1,'sensit_api.h']]],
  ['interrupt_5frising_5fegde',['INTERRUPT_RISING_EGDE',['../sensit__api_8h.html#a496e538298b0c59fa2c7265e7ed3c039a5e637c69c7b572ca01a3dc925f13341d',1,'sensit_api.h']]]
];
