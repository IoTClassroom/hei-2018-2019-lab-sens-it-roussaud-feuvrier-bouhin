var searchData=
[
  ['rc_5ffrom_5fmemory',['RC_FROM_MEMORY',['../sensit__api_8h.html#a27f9b493a5d583199778c145d0d35471a3338fab925315421e0b1459d22cc4317',1,'sensit_api.h']]],
  ['rc_5ffrom_5fparameter',['RC_FROM_PARAMETER',['../sensit__api_8h.html#a27f9b493a5d583199778c145d0d35471acddb77b77e43d19235f3f65c592e628c',1,'sensit_api.h']]],
  ['rgb_5fblue',['RGB_BLUE',['../sensit__api_8h.html#a7205560afbc85d1e838360e5143b510ba836c7bce99a78a9928a8e5dea4ca2e20',1,'sensit_api.h']]],
  ['rgb_5fcyan',['RGB_CYAN',['../sensit__api_8h.html#a7205560afbc85d1e838360e5143b510baf5e8666d7164cfa994fcb1aff6b5f9b0',1,'sensit_api.h']]],
  ['rgb_5fgreen',['RGB_GREEN',['../sensit__api_8h.html#a7205560afbc85d1e838360e5143b510bab7c62deaf7cd0fc7bc026d6b115fa50c',1,'sensit_api.h']]],
  ['rgb_5fmagenta',['RGB_MAGENTA',['../sensit__api_8h.html#a7205560afbc85d1e838360e5143b510bad66295e61ac50915c212fd803f4b21d5',1,'sensit_api.h']]],
  ['rgb_5foff',['RGB_OFF',['../sensit__api_8h.html#a7205560afbc85d1e838360e5143b510bac3802ed6e617cf93fa2f9f63d773dbd6',1,'sensit_api.h']]],
  ['rgb_5fred',['RGB_RED',['../sensit__api_8h.html#a7205560afbc85d1e838360e5143b510ba96753303de7972af7903ae2036ec1636',1,'sensit_api.h']]],
  ['rgb_5fwhite',['RGB_WHITE',['../sensit__api_8h.html#a7205560afbc85d1e838360e5143b510baf4f81e430b25fdd360cbb1d2657620e3',1,'sensit_api.h']]],
  ['rgb_5fyellow',['RGB_YELLOW',['../sensit__api_8h.html#a7205560afbc85d1e838360e5143b510ba96655a1c829f4db35815afedb5aca9b1',1,'sensit_api.h']]]
];
