var searchData=
[
  ['hts221_5finit',['HTS221_init',['../group__HTS221__API.html#gaeb41a63824477cd5cfb1bdec8fc4c15b',1,'hts221.h']]],
  ['hts221_5fmeasure',['HTS221_measure',['../group__HTS221__API.html#ga1e98494c1e4d4db46f825934e7b0ee7c',1,'hts221.h']]]
];
