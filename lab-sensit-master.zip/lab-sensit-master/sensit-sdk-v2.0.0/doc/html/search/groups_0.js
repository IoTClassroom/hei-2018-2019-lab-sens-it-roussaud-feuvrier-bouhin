var searchData=
[
  ['fxos8700_20apis',['FXOS8700 APIs',['../group__FXOS8700__API.html',1,'']]],
  ['fxos8700_20error_20codes',['FXOS8700 Error Codes',['../group__FXOS8700__ERR__CODES.html',1,'']]],
  ['fxos8700_20registers',['FXOS8700 Registers',['../group__FXOS8700__REG.html',1,'']]]
];
