var searchData=
[
  ['s16',['s16',['../sensit__types_8h.html#a5ffa4f640862b25ba6d4f635b78bdbe1',1,'sensit_types.h']]],
  ['s32',['s32',['../sensit__types_8h.html#adafe97a8e4be18b0198f234819016582',1,'sensit_types.h']]],
  ['s8',['s8',['../sensit__types_8h.html#a151f780fb455885061d3b77ec1c90c03',1,'sensit_types.h']]]
];
